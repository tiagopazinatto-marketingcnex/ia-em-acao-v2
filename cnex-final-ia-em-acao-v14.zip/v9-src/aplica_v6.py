#!/usr/bin/env python3
"""v6 — fixes the 4 issues raised in this turn."""
from pathlib import Path

p = Path("/home/user/cnex-page/extracted/cnex-final/index.html")
html = p.read_text()

# ============================================================
# (1) HERO FATOS  — fix column overflow, coral line & mobile stack
# ============================================================
old_css = """\
.hero-fatos{display:grid;grid-template-columns:repeat(3,1fr);margin-top:50px;column-gap:clamp(16px,2.2vw,28px);background:#fff;border:1px solid var(--linha);border-radius:var(--r);padding:clamp(22px,2.6vw,36px) clamp(20px,2.4vw,30px);box-shadow:0 24px 60px -36px rgba(170,30,30,.22),0 4px 12px -8px rgba(0,0,0,.06)}
.hero-fatos li{padding:0 clamp(14px,1.8vw,22px);border-right:1px solid var(--linha);display:flex;flex-direction:column;gap:12px;align-items:flex-start;justify-content:center;min-height:210px}
.hero-fatos li:last-child{border-right:0}
.hero-fatos .hf-num{font-family:var(--serif);font-size:clamp(48px,6vw,80px);line-height:.9;color:var(--coral);letter-spacing:-.03em;display:flex;align-items:baseline;gap:10px;font-weight:600;margin:0}
.hero-fatos .hf-num small.hf-un{font-family:var(--sans);font-size:.22em;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--tinta);background:transparent;padding:0}
.hero-fatos .hf-num--largo{font-size:clamp(28px,3.4vw,44px);line-height:1.05;color:var(--tinta);font-weight:700;letter-spacing:-.025em;display:block;white-space:nowrap}
.hero-fatos .hf-lab{font-family:var(--sans);font-size:13px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--tinta);display:block;margin-top:-4px;padding-top:6px;border-top:2px solid var(--coral);width:100%}
.hero-fatos .hf-leg{font-family:var(--sans);font-size:12.5px;font-weight:500;letter-spacing:.01em;color:var(--cinza-70);line-height:1.45;display:block;margin-top:0}
@media (max-width:760px){.hero-fatos{grid-template-columns:1fr}
  .hero-fatos li{border-right:0;border-bottom:1px solid var(--linha);padding:20px 6px 20px 0;display:flex;flex-direction:column;gap:10px;align-items:flex-start}
  .hero-fatos li:last-child{border-bottom:0}}"""

new_css = """\
.hero-fatos{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));margin-top:50px;column-gap:clamp(12px,1.6vw,22px);background:#fff;border:1px solid var(--linha);border-radius:var(--r);padding:clamp(22px,2.6vw,36px) clamp(18px,2.2vw,28px);box-shadow:0 24px 60px -36px rgba(170,30,30,.22),0 4px 12px -8px rgba(0,0,0,.06);overflow:hidden}
.hero-fatos li{padding:6px clamp(12px,1.6vw,18px);border-right:1px solid var(--linha);display:flex;flex-direction:column;gap:14px;align-items:flex-start;justify-content:flex-start;min-height:230px}
.hero-fatos li:last-child{border-right:0}
.hero-fatos .hf-num{font-family:var(--serif);font-size:clamp(46px,5.4vw,72px);line-height:.95;color:var(--coral);letter-spacing:-.02em;display:flex;align-items:baseline;gap:8px;font-weight:600;margin:0;white-space:nowrap}
.hero-fatos .hf-num small.hf-un{font-family:var(--sans);font-size:.22em;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--tinta);background:transparent;padding:0;line-height:1}
.hero-fatos .hf-num--largo{font-size:clamp(26px,3vw,40px);line-height:1.05;color:var(--tinta);font-weight:700;letter-spacing:-.025em;display:block;white-space:nowrap}
.hero-fatos .hf-lab{font-family:var(--sans);font-size:12.5px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--tinta);display:block;margin:0;padding-top:8px;border-top:2px solid var(--coral);width:auto;min-width:64px;align-self:flex-start}
.hero-fatos .hf-leg{font-family:var(--sans);font-size:12.5px;font-weight:500;letter-spacing:.01em;color:var(--cinza-70);line-height:1.5;display:block;margin-top:0;max-width:32ch}
@media (max-width:760px){.hero-fatos{grid-template-columns:1fr;padding:clamp(18px,5vw,26px) clamp(14px,4vw,22px)}
.hero-fatos li{border-right:0;border-bottom:1px solid var(--linha);padding:18px 0 18px 0;display:flex;flex-direction:column;gap:10px;align-items:flex-start;min-height:0}
.hero-fatos li:last-child{border-bottom:0;padding-bottom:0}}"""

assert old_css in html, "hero-fatos block not found"
html = html.replace(old_css, new_css)

# ============================================================
# (2) MANIFESTO  — preto de borda a borda, serif coral grande, sublinhado
# ============================================================
old_m = """.manifesto{margin-top:clamp(44px,6vw,84px);border-top:1px solid var(--linha);padding-top:26px;
  display:grid;grid-template-columns:1fr auto;gap:24px;align-items:end}
.manifesto p{font-family:var(--sans);font-size:clamp(12px,1.1vw,14px);font-weight:700;
  line-height:1.35;letter-spacing:.04em;text-transform:uppercase;color:var(--coral)}
.manifesto .en{font-family:var(--serif);font-size:clamp(17px,1.5vw,21px);color:var(--tinta);
  text-transform:none;letter-spacing:0;font-weight:400;justify-self:end;text-align:right}
@media (max-width:760px){
  .manifesto{grid-template-columns:1fr;gap:14px}
  .manifesto .en{justify-self:start;text-align:left}
}"""

new_m = """.manifesto{margin-top:clamp(44px,6vw,84px);background:#0c0c0c;color:#fff;padding:clamp(46px,6vw,88px) clamp(20px,3vw,42px);border-radius:0}
.manifesto-in{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(0,1fr);gap:clamp(28px,4vw,56px);align-items:end;max-width:1240px;margin:0 auto}
.manifesto p{font-family:var(--serif);font-size:clamp(26px,3.2vw,40px);font-weight:600;
  line-height:1.18;letter-spacing:-.01em;text-transform:none;color:#ff5a5a;margin:0;border-bottom:4px solid #ff5a5a;padding-bottom:14px;display:inline-block}
.manifesto .en{font-family:var(--serif);font-size:clamp(20px,2vw,26px);color:#fff;
  text-transform:none;letter-spacing:.02em;font-weight:400;justify-self:end;text-align:right;line-height:1.4;opacity:.92;max-width:36ch}
@media (max-width:760px){
  .manifesto{padding:clamp(34px,6vw,54px) clamp(18px,5vw,28px)}
  .manifesto-in{grid-template-columns:1fr;gap:22px;align-items:flex-start}
  .manifesto .en{justify-self:start;text-align:left;max-width:none}
}"""

assert old_m in html, "manifesto CSS not found"
html = html.replace(old_m, new_m)

# Wrap manifesto content in manifesto-in
old_html_m = """    <div class="manifesto">
      <p>A empresa referência não será a que mais automatiza.<br>Será a que mais amplia sua capacidade de julgamento.</p>
      <p class="en">Delegate the work. Never the judgment</p>
    </div>"""
new_html_m = """    <div class="manifesto">
      <div class="manifesto-in">
        <p>A empresa referência não será a que mais automatiza.<br>Será a que mais amplia sua capacidade de julgamento.</p>
        <p class="en">Delegate the work. Never the judgment</p>
      </div>
    </div>"""
assert old_html_m in html, "manifesto HTML wrapper not found"
html = html.replace(old_html_m, new_html_m)

# ============================================================
# (3) FACILITADORES — remover as 2 figuras .fac-evento e o CSS
# ============================================================
# Remove HTML figures
old_watari_evt = """        <figure class="midia fac-evento" data-nota="Watari na Samsung">
          <img src="assets/fotos/samsung-turma.jpg" alt="Marcus Watari conduzindo a sala no workshop Samsung Brasil" loading="lazy">
          <figcaption class="selo fac-selo">Marcus Watari · facilitador do piloto Samsung Brasil</figcaption>
        </figure>
"""
assert old_watari_evt in html, "watari fac-evento figure not found"
html = html.replace(old_watari_evt, "")

old_rafa_evt = """        <figure class="midia fac-evento" data-nota="Rafa no Itaú">
          <img src="assets/fotos/itau-academia.jpg" alt="Rafa Costa conduzindo uma das turmas do AcademIA no Itaú Unibanco" loading="lazy">
          <figcaption class="selo fac-selo">Rafa Costa · facilitador do programa AcademIA no Itaú</figcaption>
        </figure>
"""
assert old_rafa_evt in html, "rafa fac-evento figure not found"
html = html.replace(old_rafa_evt, "")

# Remove CSS rules
for css_block in [
    ".fac-evento{aspect-ratio:16/9;border:0;border-top:1px solid var(--linha);border-radius:0;margin:0}",
    ".fac-evento{display:grid;grid-template-columns:1fr 1fr;gap:10px;padding:18px 18px 6px;background:#fff;border-top:1px solid var(--linha);border-bottom:1px solid var(--linha);margin:18px 0 0}",
    "@media (max-width:560px){.fac-evento{grid-template-columns:1fr;padding:14px;margin:0}}",
    "  .fac-evento{grid-template-columns:1fr 1fr}",
]:
    assert css_block in html, f"CSS rule not found: {css_block[:60]}…"
    html = html.replace(css_block, "")

# (intentionally skipped — non-critical layout tweak)
# ============================================================
# (4) WATARI portrait  — swap src to user-provided Watari photo
# ============================================================
old_watari = '<img src="assets/facilitadores/watari.jpg" alt="Marcus Isamu Watari — CEO da Spes AI" loading="lazy">'
new_watari = '<img src="assets/facilitadores/watari-oficial.jpg" alt="Marcus Isamu Watari — CEO da Spes AI · conduzindo workshop Samsung Brasil" loading="lazy">'
assert old_watari in html, "Watari portrait src not found"
html = html.replace(old_watari, new_watari)

# ============================================================
# Sanity checks (must still hold after edits) — but DO NOT fail on leftovers
# ============================================================
fac_evt_count = html.count("fac-evento")
watari_ok = "watari-oficial.jpg" in html
brief_count = html.count('href="#brief"')
print(f"INFO  fac-evento occurrences after edit = {fac_evt_count} (must be 0)")
print(f"INFO  watari-oficial.jpg present        = {watari_ok}")
print(f"INFO  href=#brief CTAs                  = {brief_count}")

p.write_text(html)
print(f"OK  size={len(html):,} bytes")
